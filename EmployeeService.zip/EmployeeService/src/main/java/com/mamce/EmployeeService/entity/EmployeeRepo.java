package com.mamce.EmployeeService.entity;

import org.springframework.data.jpa.repository.JpaRepository;

public interface EmployeeRepo extends JpaRepository<Employees, Integer>{

	
}
